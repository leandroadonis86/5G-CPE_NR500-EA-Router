

var grid_data = [];
var colNames = [];

var keyPressed;

function check_value() {
    return true;
}

function save_data_to_storage() {

    ___data = {
        oper: "apply",
        enable: switch_obj.val()==='on'?1:0
    };

    console.log(___data)
}

function is_control_key(e){
    if(e.which === 0){
        if (e.keyCode == 35 //End
            || e.keyCode == 36 //Home
            || e.keyCode == 37 //<-
            || e.keyCode == 39 //->
            || e.keyCode == 45 //Insert
            || e.keyCode == 46 //Del
        )
            return true;
    }
    if (e.keyCode == 8  //Backspace
        || e.keyCode == 9  //Tab
        || e.keyCode == 27 //Esc
    )
        return true;
    return false;
}

function is_ipaddr(o,e) {
    var i,j;
    e = e || event;
    if (is_control_key(e))
        return true;
    keyPressed = e.keyCode ? e.keyCode : e.which;
    if (keyPressed == 0)
        return true;
    if (o.length >= 15)
        return false;
    if(keyPressed > 47 && keyPressed < 58){
        j = 0;
        for (i = 0; i < o.length; i++){
            if (o.charAt(i) == '.')
                j++;
        }
        if (j < 3 && i >= 3) {
            if (o.charAt(i - 3) != '.' && o.charAt(i - 2) != '.' && o.charAt(i - 1) != '.')
                o = o + '.';
        }
        return true;
    }
    else if(keyPressed == 46){
        j = 0;
        for (i = 0; i < o.length; i++){
            if (o.charAt(i) == '.')
                j++;
        }
        if (o.charAt(i - 1) == '.' || j == 3)
            return false;
        return true;
    }
    return false;
}

function is_iprange(o,e) {
    var ret = is_ipaddr(o,e);
    if (!ret && o.length < 15 && keyPressed == 42)
        return true;
    return ret;
}

function is_portrange(o,e) {
    e = e || event;
    if (is_control_key(e))
        return true;
    keyPressed = e.keyCode ? e.keyCode : e.which;
    if (keyPressed == 0)
        return true;
    if ((keyPressed > 47 && keyPressed < 58)){
        return true;
    }
    else if (keyPressed == 58 && o.length > 0) {
        for (i = 0; i < o.length; i++) {
            c = o.charAt(i);
            if (c == ':' || c == '>' || c == '<' || c == '=')
                return false;
        }
        return true;
    }
    else if (keyPressed == 44) {
        if (o.length == 0)
            return false;
        else
            return true;
    }
    else if (keyPressed == 60 || keyPressed == 62) {
        if (o.length == 0)
            return true;
        else
            return false;
    }
    return false;
}

function is_number(o,e) {
    e = e || event;

    if (is_control_key(e))
    {
        console.log(o+"C")
        if (Number(o) >= 65535) return false;
        return true;
    }

    keyPressed = e.keyCode ? e.keyCode : e.which;
    if (keyPressed == 0)
    {
        console.log(o+"A")
        if (Number(o) >= 65535) return false;
        return true;
    }

    if (keyPressed > 47 && keyPressed < 58) {
        if (keyPressed == 48 && o.length == 0)
        {
            return false;
        }

        console.log(o+"B")
        if (Number(o) >= 65535) return false;
        return true;
    }

    return false;
}

function validate_portrange(o,v) {
    if (o.length == 0)
        return true;

    prev = -1;
    num = -1;
    num_front = 0;
    for (var i = 0; i < o.length; i++) {
        c = o.charAt(i);
        if (c >= '0' && c <= '9') {
            if (num == -1) num = 0;
            num = num * 10 + (c - '0');
        }
        else {
            if (num > 65535 || num == 0 || (c != ':' && c != '>' && c != '<' && c != ',')) {
                return false;
            }

            if (c == '>') prev = -2;
            else if (c == '<') prev = -3;
            else if (c == ',') {
                prev = -4;
                num = 0;
            }
            else { //when c=":"
                if (prev == -4)
                    prev == -4;
                else {
                    prev = num;
                    num = 0;
                }
            }
        }
    }

    if ((num > 65535 && prev != -3) || (num < 1 && prev != -2) || (prev > num) || (num >= 65535 && prev == -2) || (num <= 1 && prev == -3)) {
        if (num > 65535) {
            return false;
        }
        else {
            return false;
        }
    } // wrong port
    else {
        if (prev == -2) {
            if (num == 65535) o = num;
            else o = (num + 1) + ":65535";  //ex. o=">2000", it will change to 2001:65535
        }
        else if (prev == -3) {
            if (num == 1) o = num;
            else o = "1:" + (num - 1);     //ex. o="<2000", it will change to 1:1999
        }
        else if (prev == -4) {
            return false;
        }
        else if (prev != -1)
            o = prev + ":" + num;
        else
            o = num;                  //single port number case;
    }
    return true;
}

function validate_iprange(o,v) {
    num = -1;
    pos = 0;
    if (o.length == 0)
        return true;
    for (i = 0; i < o.length; i++) {
        c = o.charAt(i);
        if (c >= '0' && c <= '9') {
            if (num == -1) {
                num = (c - '0');
            }
            else {
                num = num * 10 + (c - '0');
            }
        }
        else if (c == '*' && num == -1) {
            num = 0;
        }
        else {
            if (num < 0 || num > 255 || (c != '.')) {
                return false;
            }
            num = -1;
            pos++;
        }
    }
    if (pos != 3 || num < 0 || num > 255) {
        return false;
    }
    return true;
}

function init_grid_colNames() {
    colNames = [$.i18n.prop("port_jqgrid_colName_ipaddr"),
        $.i18n.prop("port_jqgrid_colName_lport"),
        $.i18n.prop("port_jqgrid_colName_srcip"),
        $.i18n.prop("port_jqgrid_colName_port"),
        $.i18n.prop("port_jqgrid_colName_proto"),
        $.i18n.prop("port_jqgrid_colName_notes")];
}

function init_grid(_data)
{
    init_grid_colNames ();

    //init grid
    {
        grid_obj.jqGrid({
            data: _data,
            datatype: "local",
            height: 200,
            colNames: colNames,
            colModel: [
                {
                    name: 'ipaddr', index: 'ipaddr', width: 150, editable: true,
                    formoptions: {elmprefix: '<span style="color:red;">(*)</span> &nbsp;&nbsp;'},
                    editoptions: {
                        size: "25",
                        maxlength: "30",
                        dataEvents: [
                            {
                                type: 'keypress', fn: function (e) {
                                    console.log('keypress');
                                    return is_ipaddr($("#ipaddr").val(), e);
                                }
                            }
                        ]
                    },
                    editrules: {
                        required: true,
                        custom: true,
                        custom_func: function (value, colNames) {
                            var regex = "^(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])\\.(\\d{1,2}|1\\d\\d|2[0-4]\\d|25[0-5])$";
                            var regexp = new RegExp(regex);
                            if (!regexp.test(value)) {
                                console.log("BIP地址格式不正确，请检查");
                                var note = $.i18n.prop("port_jqgrid_formatoption_ipaddr_check_note");
                                return [false, note];
                            } else {
                                return [true, ""];
                            }
                        }
                    }
                },
                {
                    name: 'lport', index: 'lport', width: 120, editable: true,
                    formoptions: {elmprefix: '<span style="color:red;">(*)</span> &nbsp;&nbsp;'},
                    editoptions: {
                        size: "25",
                        maxlength: "30",
                        dataEvents: [
                            {
                                type: 'keypress', fn: function (e) {
                                    console.log('keypress: ' + $("#lport").val());
                                    return is_number($("#lport").val(), e);
                                }
                            }
                        ]
                    },
                    editrules: {
                        required: true,
                        custom: true,
                        custom_func: function (value, colNames) {
                            var port = Number(value)
                            if (!(1 <= port && port <= 65535)) {
                                var note = $.i18n.prop("port_jqgrid_formatoption_lport_check_note");
                                return [false, note];
                            }
                            return [true, ""];
                        }
                    }
                },
                {
                    name: 'srcip', index: 'srcip', width: 150, editable: true,
                    formoptions: {elmprefix: '<span style="color:red;">(*)</span> &nbsp;&nbsp;'},
                    editoptions: {
                        size: "25",
                        maxlength: "30",
                        dataEvents: [
                            {
                                type: 'keypress', fn: function (e) {
                                    console.log('keypress');
                                    return is_iprange($("#srcip").val(), e);
                                }
                            }
                        ]
                    },
                    editrules: {
                        required: true,
                        custom: true,
                        custom_func: function (value, colNames) {
                            if (!validate_iprange(value)) {
                                var note = $.i18n.prop("port_jqgrid_formatoption_srcip_check_note");
                                return [false, note];
                            }
                            return [true, ""];
                        }
                    }
                },
                {
                    name: 'port', index: 'port', width: 90, editable: true,
                    formoptions: {elmprefix: '<span style="color:red;">(*)</span> &nbsp;&nbsp;'},
                    editoptions: {
                        size: "25",
                        maxlength: "30",
                        dataEvents: [
                            {
                                type: 'keypress', fn: function (e) {
                                    console.log('keypress: ' + $("#port").val());
                                    return is_portrange($("#port").val(), e);
                                }
                            }
                        ]
                    },
                    editrules: {
                        required: true,
                        custom: true,
                        custom_func: function (value, colNames) {
                            if (!validate_portrange(value)) {
                                var note = $.i18n.prop("port_jqgrid_formatoption_port_check_note");
                                return [false, note];
                            }
                            return [true, ""];
                        }
                    }
                },
                {
                    name: 'proto', index: 'proto', width: 90, editable: true, edittype: "select",
                    formoptions: {elmprefix: '<span style="color:red;">(*)</span> &nbsp;&nbsp;'},
                    editoptions: {
                        value: "BOTH:TCP/UDP;TCP:TCP;UDP:UDP"
                    },
                    formatter: proto_formater
                },
                {
                    name: 'pnote',
                    index: 'pnote',
                    width: 150,
                    sortable: false,
                    editable: true,
                    edittype: "textarea",
                    editoptions: {rows: "2", cols: "20"}
                }
            ],

            viewrecords: true,
            rowNum: 6,
            rowList: [6, 20, 30],
            pager: "#grid-pager",
            altRows: true,
            //toppager: true,

            // multiselect: true,
            //multikey: "ctrlKey",
            multiboxonly: true,

            loadComplete: function () {
                var table = this;
                setTimeout(function () {
                    styleCheckbox(table);
                    updateActionIcons(table);
                    updatePagerIcons(table);
                    enableTooltips(table);
                }, 0);
            },

            // editurl: '/goform/editFWPort.json?status=1&_=' + new Date().getTime(),//nothing is saved
            editurl: ___url,
            caption: ""
        });
    }

    //init page
    {
        //navButtons
        grid_obj.jqGrid('navGrid', "#grid-pager",
            { 	//navbar options
                edit: true,
                editicon: 'ace-icon fa fa-pencil blue',
                add: true,
                addicon: 'ace-icon fa fa-plus-circle purple',
                del: true,
                delicon: 'ace-icon fa fa-trash-o red',
                search: false,
                searchicon: 'ace-icon fa fa-search orange',
                refresh: false,
                refreshicon: 'ace-icon fa fa-refresh green',
                view: false,
                viewicon: 'ace-icon fa fa-search-plus grey',
            },
            {
                //edit record form
                //closeAfterEdit: true,
                //width: 700,
                closeAfterEdit: true,
                recreateForm: true,
                beforeShowForm: function (e) {
                    var form = $(e[0]);
                    form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
                    style_edit_form(form);
                },
                afterSubmit: function (response, e) {
                    var result = eval("(" + response.responseText + ")");
                    if (result.status === 0) {
                        grid_data = result.data.list

                        // grid_obj.jqGrid('clearGridData');
                        // grid_obj.jqGrid('setGridParam', {
                        // 	datatype: "local",
                        // 	data: grid_data
                        // }).trigger("reloadGrid");

                        return [true, ""];//Captures and displays the response text on th Edit window
                    } else {
                        return [false, result.message];//Captures and displays the response text on th Edit window
                    }
                },
                beforeSubmit: function (data, id) {
                    console.log(JSON.stringify(data))

                    var flag_xx = 0;
                    $.each(grid_data, function () {
                        console.log(this.ipaddr)
                        console.log(this.lport)
                        console.log(this.srcip)
                        console.log(this.port)
                    });

                    if (flag_xx === 0) return [true, ""]
                    else return [false, $.i18n.prop("jqgrid_row_repeat")]
                },
                serializeEditData: function (e) {
                    console.log(JSON.stringify(e))
                    var __data = {action: ___SET, data: e};
                    console.log(___data);
                    return JSON.stringify(__data);
                }
            },
            {
                //new record form
                //width: 700,
                closeAfterAdd: true,
                recreateForm: true,
                viewPagerButtons: false,
                beforeShowForm: function (e) {
                    var form = $(e[0]);
                    form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar')
                        .wrapInner('<div class="widget-header" />')
                    style_edit_form(form);
                },
                afterSubmit: function (response, e) {
                    console.log(response.responseText)
                    var result = eval("(" + response.responseText + ")");
                    if (result.status === 0) {
                        grid_data = result.data.list

                        grid_obj.jqGrid('clearGridData');
                        grid_obj.jqGrid('setGridParam', {
                            datatype: "local",
                            data: grid_data
                        }).trigger("reloadGrid");

                        return [true, ""];//Captures and displays the response text on th Edit window
                    } else {
                        return [false, result.message];//Captures and displays the response text on th Edit window
                    }
                },
                beforeSubmit: function (data, id) {
                    console.log(JSON.stringify(data))

                    var flag_xx = 0;
                    $.each(grid_data, function () {
                        console.log(this.ipaddr)
                        console.log(this.lport)
                        console.log(this.srcip)
                        console.log(this.port)
                    });

                    if (flag_xx === 0) return [true, ""]
                    else return [false, $.i18n.prop("jqgrid_row_repeat")]
                },
                serializeEditData: function (e) {
                    e.protono = "";
                    console.log(JSON.stringify(e))
                    var __data = {action: ___SET, data: e};
                    console.log(___data);
                    return JSON.stringify(__data);
                }
            },
            {
                //delete record form
                closeAfterEdit: true,
                recreateForm: true,
                beforeShowForm: function (e) {
                    var form = $(e[0]);
                    if (form.data('styled')) return false;

                    form.closest('.ui-jqdialog').find('.ui-jqdialog-titlebar').wrapInner('<div class="widget-header" />')
                    style_delete_form(form);

                    form.data('styled', true);
                },
                afterSubmit: function (response, e) {
                    var result = eval("(" + response.responseText + ")");
                    if (result.status === 0) {
                        grid_data = result.data.list
                        // grid_obj.jqGrid('clearGridData');
                        // grid_obj.jqGrid('setGridParam', {
                        // 	datatype: "local",
                        // 	data: result.data.list
                        // }).trigger("reloadGrid");

                        return [true, ""];//Captures and displays the response text on th Edit window
                    } else {
                        return [false, result.message];//Captures and displays the response text on th Edit window
                    }
                },
                serializeDelData: function (e) {
                    // {"oper":"del","id":"1,2,3"}
                    // {"action":"set_macacl","data":{"oper":"del","id":"1,2,3"}}
                    console.log(JSON.stringify(e))
                    var __data = {action: ___SET, data: {oper: e.oper, list: e.id.split(',')}};
                    console.log(___data);
                    return JSON.stringify(__data);
                }
            },
            {
                //search form
            },
            {
                //view record form
            }
        );
    }
}

function proto_formater(cellvalue, options, rowObject) {
    if(cellvalue==="BOTH") return "TCP/UDP";
    return cellvalue;
}

//unlike navButtons icons, action icons in rows seem to be hard-coded
//you can change them like this in here if you want
function updateActionIcons(table) {
    /**
     var replacement =
     {
				'ui-ace-icon fa fa-pencil' : 'ace-icon fa fa-pencil blue',
				'ui-ace-icon fa fa-trash-o' : 'ace-icon fa fa-trash-o red',
				'ui-icon-disk' : 'ace-icon fa fa-check green',
				'ui-icon-cancel' : 'ace-icon fa fa-times red'
			};
     $(table).find('.ui-pg-div span.ui-icon').each(function(){
				var icon = $(this);
				var $class = $.trim(icon.attr('class').replace('ui-icon', ''));
				if($class in replacement) icon.attr('class', 'ui-icon '+replacement[$class]);
			})
     */
}

//it causes some flicker when reloading or navigating grid
//it may be possible to have some custom formatter to do this as the grid is being created to prevent this
//or go back to default browser checkbox styles for the grid
function styleCheckbox(table) {
    /**
     $(table).find('input:checkbox').addClass('ace')
     .wrap('<label />')
     .after('<span class="lbl align-top" />')


     $('.ui-jqgrid-labels th[id*="_cb"]:first-child')
     .find('input.cbox[type=checkbox]').addClass('ace')
     .wrap('<label />').after('<span class="lbl align-top" />');
     */
}

function enableTooltips(table) {
    $('.navtable .ui-pg-button').tooltip({container:'body'});
    $(table).find('.ui-pg-div').tooltip({container:'body'});
}

//replace icons with FontAwesome icons like above
function updatePagerIcons(table) {
    var replacement =
        {
            'ui-icon-seek-first' : 'ace-icon fa fa-angle-double-left bigger-140',
            'ui-icon-seek-prev' : 'ace-icon fa fa-angle-left bigger-140',
            'ui-icon-seek-next' : 'ace-icon fa fa-angle-right bigger-140',
            'ui-icon-seek-end' : 'ace-icon fa fa-angle-double-right bigger-140'
        };
    $('.ui-pg-table:not(.navtable) > tbody > tr > .ui-pg-button > .ui-icon').each(function(){
        var icon = $(this);
        var $class = $.trim(icon.attr('class').replace('ui-icon', ''));

        if($class in replacement) icon.attr('class', 'ui-icon '+replacement[$class]);
    })

    $(window).triggerHandler('resize.jqGrid');//trigger window resize to make the grid get the correct size
}

function style_edit_form(form) {

    // $("#id_note_ipaddr").attr("title", $.i18n.prop("port_jqgrid_formatoption_ipaddr_help_note"));
    // $("#id_note_lport").attr("title", $.i18n.prop("port_jqgrid_formatoption_lport_help_note"));
    // $("#id_note_srcip").attr("title", $.i18n.prop("port_jqgrid_formatoption_srcip_help_note"));
    // $("#id_note_port").attr("title", $.i18n.prop("port_jqgrid_formatoption_port_help_note"));

    $('#ipaddr').attr('placeholder', $.i18n.prop('port_jqgrid_formatoption_ipaddr_help_note'));
    $('#lport').attr('placeholder', $.i18n.prop('port_jqgrid_formatoption_lport_help_note'));
    $('#srcip').attr('placeholder', $.i18n.prop('port_jqgrid_formatoption_srcip_help_note'));
    $('#port').attr('placeholder', $.i18n.prop('port_jqgrid_formatoption_port_help_note'));

    // $("#id_note_ipaddr").bind("click",function(){
    // 	console.log("id_note_ipaddr");
    // 	bootbox.alert("Hello world!", function() {
    // 		console.log("Hello world callback");
    // 	});
    // });

    //update buttons classes
    var buttons = form.next().find('.EditButton .fm-button');
    buttons.addClass('btn btn-sm').find('[class*="-icon"]').hide();//ui-icon, s-icon
    buttons.eq(0).addClass('btn-primary').prepend('<i class="ace-icon fa fa-check"></i>');
    buttons.eq(1).prepend('<i class="ace-icon fa fa-times"></i>')

    // buttons = form.next().find('.navButton a');
    // buttons.find('.ui-icon').hide();
    // buttons.eq(0).append('<i class="ace-icon fa fa-chevron-left"></i>');
    // buttons.eq(1).append('<i class="ace-icon fa fa-chevron-right"></i>');
}

function style_delete_form(form) {
    var buttons = form.next().find('.EditButton .fm-button');
    buttons.addClass('btn btn-sm btn-white btn-round').find('[class*="-icon"]').hide();//ui-icon, s-icon
    buttons.eq(0).addClass('btn-danger').prepend('<i class="ace-icon fa fa-trash-o"></i>');
    buttons.eq(1).addClass('btn-default').prepend('<i class="ace-icon fa fa-times"></i>')
}
