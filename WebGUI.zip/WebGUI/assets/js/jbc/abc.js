/**
 * cookie操作
 */
var getCookiex = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        var path = options.path ? '; path=' + options.path : '';
        var domain = options.domain ? '; domain=' + options.domain : '';
        var s = [cookie, expires, path, domain, secure].join('');
        var secure = options.secure ? '; secure' : '';
        var c = [name, '=', encodeURIComponent(value)].join('');
        var cookie = [c, expires, path, domain, secure].join('')
        document.cookie = cookie;
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};

var ___loading_title = '数据处理中，请稍候。。。';

var jbc_loading = function (option) {
    var _interval = 2000;
    var contentArea = $('.page-content-area');
    contentArea.css('opacity', 0.25)
    var loading_icon = 'fa-spinner fa-2x orange';
    var loading_text = option.loading_text || ___loading_title;
    var interval = option.interval || _interval

    var loader = $('<div style="position: fixed; z-index: 2000;" class="ajax-loading-overlay"><i class="ajax-loading-icon fa fa-spin '+loading_icon+'"></i><div class="jbc_loading center"> '+loading_text+'</div></div>').insertBefore(contentArea);

    var offset = contentArea.offset();
    loader.css({top: offset.top, left: offset.left})

    setTimeout(function() {
        contentArea.css('opacity', 0.8)
        contentArea.css('opacity', 1)
        contentArea.prevAll('.ajax-loading-overlay').remove();
    }, interval)
}

var trim = function (s)
{
    if (s == null) return s;

    var i;
    var beginIndex = 0;
    var endIndex = s.length - 1;

    for (i=0; i<s.length; i++)
    {
        if (s.charAt(i) == ' ' || s.charAt(i) == '　') beginIndex++;
        else break;
    }

    for (i = s.length - 1; i >= 0; i--)
    {
        if (s.charAt(i) == ' ' || s.charAt(i) == '　') endIndex--;
        else break;
    }

    if (endIndex < beginIndex) return "";

    return s.substring(beginIndex, endIndex + 1);
}

var checkIP = function (ip){
    var exp=/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-4]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    return exp.test(ip);
}

var _checkIP = function (value){
    var exp=/^(\d{1,2}|1\d\d|2[0-5]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-5]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-5]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-5]\d|25[0-4])$/;
    var reg = value.match(exp);
    if(reg==null)
    {
        return false;
    }

    return true
}
/**
 * 函数名：   _checkIput_fomartIP
 * 函数功能： 返回传入参数对应的8位二进制值
 * 传入参数： ip:点分十进制的值(0~255),int类型的值，
 * 主调函数： validateMask
 * 返回值:    ip对应的二进制值(如：传入255，返回11111111;传入1,返回00000001)
 **/
var _checkIput_fomartIP = function (ip)
{
    return (ip+256).toString(2).substring(1); //格式化输出(补零)
}

/**
 * 函数名：   validateMask
 * 函数功能： 验证子网掩码的合法性
 * 传入参数： MaskStr:点分十进制的子网掩码(如：255.255.255.192)
 * 调用函数： _checkIput_fomartIP(ip)
 * 返回值：   true:MaskStr为合法子网掩码 false: MaskStr为非法子网掩码
 **/
var checkMask = function (MaskStr)
{
    /* 有效性校验 */
    var IPPattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/

    if(!IPPattern.test(MaskStr)) return false;

    /* 检查域值 */
    var IPArray = MaskStr.split(".");
    var ip1 = parseInt(IPArray[0]);
    var ip2 = parseInt(IPArray[1]);
    var ip3 = parseInt(IPArray[2]);
    var ip4 = parseInt(IPArray[3]);

    /* 每个域值范围0-255 */
    if ( ip1<0 || ip1>255
        || ip2<0 || ip2>255
        || ip3<0 || ip3>255
        || ip4<0 || ip4>=255 ) return false;

    /* 检查二进制值是否合法 */
    //拼接二进制字符串
    var ip_binary = _checkIput_fomartIP(ip1) + _checkIput_fomartIP(ip2) + _checkIput_fomartIP(ip3) + _checkIput_fomartIP(ip4);

    if(-1 != ip_binary.indexOf("01")) return false;

    return true;
}

var parseURL = function (url) {
    var a = document.createElement('a');
    a.href = url;
    return {
        source: url,
        protocol: a.protocol.replace(':', ''),
        host: a.hostname,
        port: a.port,
        query: a.search,
        params: (function () {
            var ret = {},
                seg = a.search.replace(/^\?/, '').split('&'),
                len = seg.length, i = 0, s;
            for (; i < len; i++) {
                if (!seg[i]) { continue; }
                s = seg[i].split('=');
                ret[s[0]] = s[1];
            }
            return ret;
        })(),
        file: (a.pathname.match(/\/([^\/?#]+)$/i) || [, ''])[1],
        hash: a.hash.replace('#', ''),
        path: a.pathname.replace(/^([^\/])/, '/$1'),
        relative: (a.href.match(/tps?:\/\/[^\/]+(.+)/) || [, ''])[1],
        segments: a.pathname.replace(/^\//, '').split('/')
    };
}

var checkURL = function (url) {
    url = trim(url);

    if (url.length===0 || url.length < 8) return false;

    var myURL = parseURL(url);

    if (myURL.path.length < 1) return false;
    if (myURL.host.indexOf(" ") >= 0) return false;

    return true;
}

var isRealNum = function (val){
    // isNaN()函数 把空串 空格 以及NUll 按照0来处理 所以先去除
    if(val === "" || val ==null){
        return false;
    }

    return !isNaN(val);
}

var check_ussd = function (ussd) {
    var c;
    var ch = "0123456789ABCDEFabcdefGHIJKLMNOPQRSTUVWXYZghijklmnopqrstuvwxyz*#";

    for (var i = 0; i < ussd.length; i++) {
        c = ussd.charAt(i);
        if (ch.indexOf(c) == -1) {
            return false;
        }
    }
    return true;
}

var check_name = function (ssid) {
    var c;
    var ch = "0123456789ABCDEFabcdefGHIJKLMNOPQRSTUVWXYZghijklmnopqrstuvwxyz!@#$%^_+=-~?.";

    for (var i = 0; i < ssid.length; i++) {
        c = ssid.charAt(i);
        if (ch.indexOf(c) == -1) {
            return false;
        }
    }
    return true;
}

var checkHex = function (str) {
    var len = str.length;
    for (var i = 0; i < len; i++) {
        if ((str.charAt(i) >= '0' && str.charAt(i) <= '9') ||
            (str.charAt(i) >= 'a' && str.charAt(i) <= 'f') ||
            (str.charAt(i) >= 'A' && str.charAt(i) <= 'F')) {
            continue;
        } else
            return false;
    }
    return true;
}

var checkInjection = function (str) {
    var len = str.length;
    for (var i = 0; i < len; i++) {
        if (str.charAt(i) == '\r' || str.charAt(i) == '\n' || str.charAt(i) == ' ') {
            return false;
        } else
            continue;
    }
    return true;
}

//查询是否为数字类型
function isDigit(cCheck)
{
    return (('0'<=cCheck) && (cCheck<='9'));
}

var checkNumber = function (s)
{
    if(s==null)return false;
    s=trim(s);
    for (var i=0; i < s.length; i++)
    {
        var c = s.charAt(i);
        if (!(isDigit(c)))
        {
            return false;
        }
    }
    return true;
}

var compare_ip = function (ipBegin, ipEnd)
{
    var temp1;
    var temp2;

    temp1 = ipBegin.split(".");
    temp2 = ipEnd.split(".");

    for (var i = 0; i < 4; i++)
    {
        if (Number(temp1[i]) > Number(temp2[i]))
            return 1;
        else if (Number(temp1[i]) < Number(temp2[i]))
            return -1;
    }

    return 0;
}
 
var isEqualIPAddressEx = function (addr1,addr2,mask) {
    if (!addr1 || !addr2 || !mask) {
        console.log("各参数不能为空");
        return false;
    }
    var res1 = [];
    var res2 = [];
    addr1 = addr1.split(".");
    addr2 = addr2.split(".");
    mask = mask.split(".");
    for (var i = 0, ilen = addr1.length; i < ilen; i += 1) {
        res1.push(parseInt(addr1[i]) & parseInt(mask[i]));
        res2.push(parseInt(addr2[i]) & parseInt(mask[i]));
    }
    if (res1.join(".") == res2.join(".")) {
        console.log("在同一个网段");
        return true;
    } else {
        console.log("不在同一个网段");
        return false;
    }
}

var isEqualIPAddress = function (addr1, addr2, mask){
    if(!addr1 || !addr2 || !mask){
        return false;
    }

    var res1 = [], res2 = [];
    addr1 = addr1.split(".");
    addr2 = addr2.split(".");
    let o="00000000"
    for(var i = 0,ilen = addr1.length; i < ilen ; i += 1){
        let num1 = parseInt(addr1[i]).toString("2")
        if(num1.length!=8){
            let site=8-num1.length
            num1 = o.slice(0,site)+num1
        }
        let num2 = parseInt(addr2[i]).toString("2")
        if(num2.length!=8){
            let site=8-num2.length
            num2 = o.slice(0,site)+num2
        }
        res1.push(num1);
        res2.push(num2);
    }

    if(res1.join("").slice(0,parseInt(mask)) == res2.join("").slice(0,parseInt(mask))){
        return true;
    }else{
        return false;
    }
}

var show_loading = function (title) {
    contentArea = $('.page-content-area');
    contentArea.css('opacity', 0.25)
    var loading_icon = 'fa-spinner fa-2x orange';
    var loading_text = title || ___loading_title; // '数据处理中，请稍候。。。';

    var loader = $('<div style="position: fixed; z-index: 2000;" class="ajax-loading-overlay"><i class="ajax-loading-icon fa fa-spin '+loading_icon+'"></i><div class="jbcv2_loading center"> '+loading_text+'</div></div>').insertBefore(contentArea);

    var offset = contentArea.offset();
    loader.css({top: offset.top, left: offset.left, width: contentArea.width()})
}

var hide_loading = function () {
    contentArea = $('.page-content-area');
    contentArea.css('opacity', 0.8)
    contentArea.css('opacity', 1)
    contentArea.prevAll('.ajax-loading-overlay').remove();
}

var show_loadingv2 = function (o, title) {
    contentArea = o;
    contentArea.css('opacity', 0.25)
    var loading_icon = 'fa-spinner fa-2x orange';
    var loading_text = title || ___loading_title; // '数据处理中，请稍候。。。';

    var loader = $('<div style="position: fixed; z-index: 2000;" class="ajax-loading-overlay"><i class="ajax-loading-icon fa fa-spin '+loading_icon+'"></i><div class="jbc_loading center"> '+loading_text+'</div></div>').insertBefore(contentArea);

    var offset = contentArea.offset();
    loader.css({top: offset.top, left: offset.left})
}

var hide_loadingv2 = function (o) {
    contentArea = o;
    contentArea.css('opacity', 0.8)
    contentArea.css('opacity', 1)
    contentArea.prevAll('.ajax-loading-overlay').remove();
}

var show_loadingv3 = function (title) {
    let _contentArea = $('.page-content-area');
    contentArea = $('.div_loading');
    contentArea.css('opacity', 0.25)
    var loading_icon = 'fa-spinner fa-2x orange';
    var loading_text = title || ___loading_title; // '数据处理中，请稍候。。。';

    var loader = $('<div style="position: fixed; z-index: 2000;" class="ajax-loading-overlay"><i class="ajax-loading-icon fa fa-spin '+loading_icon+'"></i><div class="jbc_loading center"> '+loading_text+'</div></div>').insertBefore(contentArea);

    var offset = _contentArea.offset();
    loader.css({top: offset.top, left: offset.left})
}

var hide_loadingv3 = function () {
    contentArea = $('.div_loading');
    contentArea.css('opacity', 0.8)
    contentArea.css('opacity', 1)
    contentArea.prevAll('.ajax-loading-overlay').remove();
}

var refresh_select = function () {
    $('.chosen-select').chosen({allow_single_deselect:true});
    //resize the chosen on window resize

    $(window)
        .off('resize.chosen')
        .on('resize.chosen', function() {
            $('.chosen-select').each(function() {
                var $this = $(this);
                $this.next().css({'width': $this.parent().width()});
            })
        }).trigger('resize.chosen');
};

var getMyDate = function (s,t) {
    if (t===0) return Math.floor(s / (60*60*24));
    if (t===1) {
        s = Math.floor(s % (60*60*24));
        return Math.floor(s / (60*60));
    }
    if (t===2) {
        s = Math.floor(s % (60*60*24));
        s = Math.floor(s % (60*60));
        return Math.floor(s / (60));
    }

    s = Math.floor(s % (60*60*24));
    s = Math.floor(s % (60*60));
    return s = Math.floor(s % (60));
};

var getTimesByZone = function () {
    //得到本地时间
    var d = new Date();

    //得到1970年一月一日到现在的秒数
    var local = d.getTime();

    //本地时间与GMT时间的时间偏移差
    var offset = d.getTimezoneOffset() * 60000;

    //获取本地时区，判断如果是负的则相加得到GMC时间，正的则相减
    var localUtc = new Date().getTimezoneOffset() / 60;

    //得到现在的格林尼治时间
    var utcTime;
    if (localUtc > 0) {
        utcTime = parseInt(local - offset);
    } else {
        utcTime = parseInt(local + offset);
    }

    //得到时区的绝对值
    var localTime = utcTime + 3600000 * Math.abs(localUtc);

    let date = new Date(localTime);
    console.log("根据本地时间得知" + localUtc + "时区的时间是 " + date.toLocaleString());
    console.log("系统默认展示时间方式是：" + localTime)

    return localTime;
};

var ___url = "/goform/formJsonAjaxReq";
var __ref;
